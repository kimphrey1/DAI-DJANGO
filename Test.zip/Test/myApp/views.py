from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required,user_passes_test
from django.contrib.auth.models import Group
from django.contrib import auth
from django.http import HttpResponseRedirect
from .forms import FeedbackForm
from .models import Feedback
from django.contrib import messages  # Import messages module for user feedback

# Create your views here.

def feedback_form(request):
    if request.method == 'POST':
        form = FeedbackForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Thank you for your feedback!')
            return redirect('feedback_success')
        
        else:
            messages.error(request, 'Form submission failed. Please check your input.')
    else:
        form = FeedbackForm()

    return render(request, 'feedback_form.html', {'form': form})

def feedback_success(request):
    return render(request, 'feedback_success.html')

def admin_view(request):
    feedback_entries = Feedback.objects.all()
    return render(request, 'admin.html', {'feedback_entries': feedback_entries})
