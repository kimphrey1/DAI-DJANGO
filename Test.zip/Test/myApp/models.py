from django.db import models

# Create your models here.

class Feedback(models.Model):
    student_number = models.IntegerField(default = "2100700000")
    registration_number = models.CharField(max_length=20)
    name = models.CharField(max_length=100)
    email = models.EmailField()
    date_of_birth = models.DateField(default="YYYY-MM-DD")
    address = models.TextField()
    message = models.TextField()
